import { Telegraf, Markup, Context } from "telegraf";
import dotenv from "dotenv";
import path from "path";
import fs from "fs";

dotenv.config({ path: path.resolve(process.cwd(), "../.env") });
const token = process.env.BOT_TOKEN;
if (!token) {
  console.error("BOT_TOKEN is missing. Add your Telegram bot token to the root .env file.");
  process.exit(1);
}

 type Language = "ru" | "uz" | "en";
type UserRecord = {
  telegramId: number;
  username: string | null;
  firstName: string;
  lastName: string;
  language: Language;
  registeredAt: string;
};
type PendingRecord = { step: "firstName" | "lastName"; language: Language; firstName?: string };
type Store = { users: Record<string, UserRecord>; pending: Record<string, PendingRecord> };

const rootDir = path.resolve(process.cwd(), "..");
const dataDir = path.join(rootDir, "data");
const dataFile = path.join(dataDir, "users.json");
fs.mkdirSync(dataDir, { recursive: true });
function readStore(): Store {
  try {
    if (fs.existsSync(dataFile)) return JSON.parse(fs.readFileSync(dataFile, "utf8")) as Store;
  } catch (error) {
    console.error("Could not read data/users.json:", error);
  }
  return { users: {}, pending: {} };
}
let store = readStore();
function saveStore(): void {
  const tempFile = `${dataFile}.tmp`;
  fs.writeFileSync(tempFile, JSON.stringify(store, null, 2), "utf8");
  fs.renameSync(tempFile, dataFile);
}

const copy = {
  ru: {
    welcome: "Добро пожаловать в SAYR CLUB! 🌆\n\nОткрывай интересные места, события и новые впечатления вместе с нами.\n\nСначала выбери язык:",
    askFirst: "Отлично! Как тебя зовут? Напиши своё имя.",
    askLast: "Приятно познакомиться, {name}! Теперь напиши фамилию.",
    done: "Регистрация завершена! 🎉\n\nДобро пожаловать в SAYR CLUB, {name}! Теперь ты можешь открывать новые места и впечатления.",
    already: "Ты уже зарегистрирован(а) в SAYR CLUB, {name}! 🙌\n\nМожешь открыть приложение ниже.",
    open: "🚀 Открыть SAYR CLUB",
    cancel: "Регистрация отменена. Чтобы начать заново, отправь /start.",
    invalid: "Пожалуйста, напиши имя или фамилию текстом (от 2 до 50 символов).",
    noApp: "Приложение пока не опубликовано по публичной HTTPS-ссылке. Регистрация сохранена — ссылка на Mini App появится после настройки WEB_APP_URL.",
  },
  uz: {
    welcome: "SAYR CLUB’ga xush kelibsiz! 🌆\n\nBiz bilan qiziqarli joylar, tadbirlar va yangi taassuroflarni kashf eting.\n\nAvval tilni tanlang:",
    askFirst: "Ajoyib! Ismingiz nima? Ismingizni yozing.",
    askLast: "Tanishganimdan xursandman, {name}! Endi familiyangizni yozing.",
    done: "Ro‘yxatdan o‘tish yakunlandi! 🎉\n\nSAYR CLUB’ga xush kelibsiz, {name}! Endi yangi joylar va taassuroflarni kashf qilishingiz mumkin.",
    already: "Siz SAYR CLUB’da ro‘yxatdan o‘tgansiz, {name}! 🙌\n\nIlovani quyidagi tugma orqali ochishingiz mumkin.",
    open: "🚀 SAYR CLUB’ni ochish",
    cancel: "Ro‘yxatdan o‘tish bekor qilindi. Qayta boshlash uchun /start yuboring.",
    invalid: "Iltimos, ism yoki familiyangizni matn ko‘rinishida yozing (2–50 belgi).",
    noApp: "Ilova hali ommaviy HTTPS havolaga joylanmagan. Ro‘yxatdan o‘tish saqlandi — WEB_APP_URL sozlangach Mini App havolasi paydo bo‘ladi.",
  },
  en: {
    welcome: "Welcome to SAYR CLUB! 🌆\n\nDiscover interesting places, events, and new experiences with us.\n\nFirst, choose your language:",
    askFirst: "Great! What is your first name?",
    askLast: "Nice to meet you, {name}! Now enter your last name.",
    done: "Registration complete! 🎉\n\nWelcome to SAYR CLUB, {name}! You can now discover new places and experiences.",
    already: "You are already registered with SAYR CLUB, {name}! 🙌\n\nYou can open the app below.",
    open: "🚀 Open SAYR CLUB",
    cancel: "Registration cancelled. Send /start to begin again.",
    invalid: "Please enter your first or last name as text (2–50 characters).",
    noApp: "The app is not published at a public HTTPS address yet. Your registration is saved; the Mini App link will appear once WEB_APP_URL is configured.",
  },
} satisfies Record<Language, Record<string, string>>;

const bot = new Telegraf(token);
const languageKeyboard = Markup.inlineKeyboard([
  [Markup.button.callback("🇷🇺 Русский", "lang:ru")],
  [Markup.button.callback("🇺🇿 O'zbekcha", "lang:uz")],
  [Markup.button.callback("🇬🇧 English", "lang:en")],
]);
function validName(value: string): boolean {
  const clean = value.trim();
  return clean.length >= 2 && clean.length <= 50 && !/[\r\n]/.test(clean);
}
function appKeyboard(language: Language) {
  const url = process.env.WEB_APP_URL?.trim();
  if (url && /^https:\/\//i.test(url) && !url.includes("example.com")) {
    return Markup.inlineKeyboard([[Markup.button.webApp(copy[language].open, url)]]);
  }
  return undefined;
}
function displayName(user: UserRecord): string {
  return `${user.firstName} ${user.lastName}`.trim();
}

bot.start(async (ctx) => {
  const id = String(ctx.from.id);
  const existing = store.users[id];
  if (existing) {
    const lang = existing.language;
    const keyboard = appKeyboard(lang);
    await ctx.reply(copy[lang].already.replace("{name}", existing.firstName), keyboard ?? undefined);
    if (!keyboard) await ctx.reply(copy[lang].noApp);
    return;
  }
  delete store.pending[id];
  saveStore();
  await ctx.reply(copy.ru.welcome, languageKeyboard);
});

bot.action(/^lang:(ru|uz|en)$/, async (ctx) => {
  const language = ctx.match[1] as Language;
  const id = String(ctx.from.id);
  if (store.users[id]) {
    await ctx.answerCbQuery();
    await ctx.reply(copy[store.users[id].language].already.replace("{name}", store.users[id].firstName));
    return;
  }
  store.pending[id] = { step: "firstName", language };
  saveStore();
  await ctx.answerCbQuery();
  await ctx.editMessageText(copy[language].askFirst);
});

bot.command("cancel", async (ctx) => {
  const id = String(ctx.from.id);
  const pending = store.pending[id];
  delete store.pending[id];
  saveStore();
  await ctx.reply(copy[pending?.language ?? "ru"].cancel);
});

bot.on("text", async (ctx) => {
  const id = String(ctx.from.id);
  const pending = store.pending[id];
  if (!pending) return;
  const text = ctx.message.text.trim();
  if (text.startsWith("/")) return;
  const language = pending.language;
  if (!validName(text)) {
    await ctx.reply(copy[language].invalid);
    return;
  }
  if (pending.step === "firstName") {
    store.pending[id] = { step: "lastName", language, firstName: text };
    saveStore();
    await ctx.reply(copy[language].askLast.replace("{name}", text));
    return;
  }
  const firstName = pending.firstName ?? "";
  const user: UserRecord = {
    telegramId: ctx.from.id,
    username: ctx.from.username ?? null,
    firstName,
    lastName: text,
    language,
    registeredAt: new Date().toISOString(),
  };
  store.users[id] = user;
  delete store.pending[id];
  saveStore();
  await ctx.reply(copy[language].done.replace("{name}", firstName), appKeyboard(language) ?? undefined);
  if (!appKeyboard(language)) await ctx.reply(copy[language].noApp);
});

bot.catch((error, ctx: Context) => {
  console.error(`SAYR CLUB bot error for update ${ctx.update.update_id}:`, error);
});

bot.launch().then(() => console.log("SAYR CLUB bot is running. Registration flow is active."));
process.once("SIGINT", () => bot.stop("SIGINT"));
process.once("SIGTERM", () => bot.stop("SIGTERM"));
