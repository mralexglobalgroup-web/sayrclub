export default function App() {
  return (
    <main className="page">
      <section className="hero">
        <div className="logo">sayr<span>club.</span></div>
        <p className="eyebrow">PEOPLE. PLACES. EXPERIENCES.</p>
        <h1>Твой город.<br />Твои впечатления.</h1>
        <p className="description">
          SAYR CLUB поможет открывать интересные места, события и новые впечатления.
        </p>
        <div className="status">Платформа готовится к запуску</div>
      </section>
      <footer>© SAYR CLUB</footer>
    </main>
  );
}
