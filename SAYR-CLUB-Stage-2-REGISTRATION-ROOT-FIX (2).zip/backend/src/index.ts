import express from "express";
import cors from "cors";
import dotenv from "dotenv";
import path from "path";

dotenv.config({ path: path.resolve(process.cwd(), "../.env") });
const app = express();
const port = Number(process.env.API_PORT || 3001);

app.use(cors());
app.use(express.json());
app.get("/health", (_req, res) => res.json({ ok: true, service: "sayr-club-api" }));

app.listen(port, () => {
  console.log(`SAYR CLUB API listening on http://localhost:${port}`);
});
