@echo off
title SAYR CLUB - Stage 1 setup
cd /d "%~dp0"
echo.
echo SAYR CLUB - Stage 1
echo ------------------
echo Project folder: %CD%
echo.
if not exist "package.json" (
  echo ERROR: package.json was not found in this folder.
  echo Open the extracted folder that contains package.json in VS Code.
  pause
  exit /b 1
)
where node >nul 2>nul
if errorlevel 1 (
  echo ERROR: Node.js was not found in PATH.
  echo Install Node.js LTS from https://nodejs.org and restart VS Code.
  pause
  exit /b 1
)
echo Node version:
node -v
echo.
echo Installing project dependencies...
call npm.cmd install
if errorlevel 1 (
  echo.
  echo Dependency installation failed. Read the error above.
  pause
  exit /b 1
)
if not exist ".env" copy ".env.example" ".env" >nul
echo.
echo Setup finished. Add BOT_TOKEN to the .env file before starting the bot.
pause
