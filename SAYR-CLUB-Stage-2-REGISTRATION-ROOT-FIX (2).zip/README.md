# SAYR CLUB — Stage 2: Telegram Registration

This archive continues the saved `SAYR-CLUB-Stage-1-ROOT-FIX` project. The folder layout and the Windows-friendly `npm.cmd` workflow are preserved.

## Requirements
- Node.js 20 or newer
- Visual Studio Code
- Internet connection for the first dependency installation

Java is not required. This project uses TypeScript/JavaScript and Node.js.

## Install / update dependencies
Open the extracted project folder in VS Code — the folder that contains the root `package.json` — then run:

```powershell
npm.cmd install
```

## Configure the root `.env`
Create a file named `.env` in the same folder as the root `package.json` (not `.env.example`). Add:

```env
BOT_TOKEN=PASTE_YOUR_BOTFATHER_TOKEN_HERE
WEB_APP_URL=https://example.com
API_PORT=3001
NODE_ENV=development
```

Replace `BOT_TOKEN` with the token from BotFather. Never share the token or commit `.env`.

`WEB_APP_URL` must be the public HTTPS URL of the deployed Telegram Mini App. `https://example.com` is only a placeholder; while it remains unchanged, registration still works but the bot explains that the Mini App URL has not been configured yet and does not show a non-working launch button.

## Start services
Run each command in its own VS Code terminal:

```powershell
npm.cmd run dev:api
```

```powershell
npm.cmd run dev:web
```

```powershell
npm.cmd run dev:bot
```

The API health check is `http://localhost:3001/health`; the web development page is `http://localhost:5173`.

## Registration flow
1. `/start` displays a welcome message and three inline language buttons: Russian, Uzbek, English.
2. The selected language is used for the rest of the registration.
3. The bot asks for first name and then last name.
4. It validates each name (2–50 characters).
5. It saves Telegram ID, username, first name, last name, language, and registration timestamp in `data/users.json` at the project root.
6. A registered user who sends `/start` again is not asked to register again.
7. `/cancel` cancels an unfinished registration.
8. Once `WEB_APP_URL` is set to the real public HTTPS Mini App URL, a Telegram Web App button appears after registration.

The data file is created automatically. Keep the `data` folder when moving the project so registrations are retained. This JSON storage is suitable for the current single-bot development stage; for a multi-instance production deployment, move to a managed database.

## Notes
- If PowerShell does not recognize `npm`, use `npm.cmd` as shown above.
- Do not run two bot processes with the same token at once; stop the old bot terminal with `Ctrl+C` before restarting.
- If port 3001 is already in use, stop the other API terminal before starting another copy.
